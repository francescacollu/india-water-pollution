GLOBAL HEALTH OBSERVATORY DOWNLOAD
====================================
This zip data file has been downloaded from 

	Name: Water, sanitation and hygiene: burden of disease
	URL: https://www.who.int/data/gho/data/themes/topics/water-sanitation-and-hygiene-burden-of-disease
	Description: 
	Climate change is impacting human lives and health in a variety of ways. 
 It threatens the essential ingredients of good health - clean air, safe drinking water, nutritious food supply, and safe shelter - and has the potential to undermine decades of progress in global health.�Between 2030 and 2050, climate change is expected to cause approximately 250 000 additional deaths per year, from malnutrition, malaria, diarrhoea and heat stress alone. The direct damage costs to health is estimated to be between USD 2-4 billion per
    year by 2030.�Areas with weak health infrastructure � mostly in developing countries � will be the least able to cope without assistance to prepare and respond. WHO supports countries in building climate-resilient health systems and tracking national
        progress in protecting health from climate change.Climate change and health fact sheet
	
	Date generated: 2023-03-01

It contains csv files divided into two folders: data and codes

	data: contains one csv file per indicator under "Water, sanitation and hygiene: burden of disease"
	
	codes: contains one csv file per disaggregation/dimension used in the data files
	


Hierarchy

	parent: public-health-and-environment
	self: water-sanitation-and-hygiene-burden-of-disease
	children: 
		WSH_20_HYG	Attributable fraction of diarrhoea to inadequate hygiene
		WSH_20_SAN	Attributable fraction of diarrhoea to inadequate sanitation
		WSH_20_WAT	Attributable fraction of diarrhoea to inadequate water
		WSH_20	Attributable fraction of diarrhoea to inadequate water, sanitation and hygiene
		SDGWSHBOD	Mortality rate attributed to exposure to unsafe WASH services (per 100 000 population) (SDG 3.9.2)
		WSH_30_HYG	Number of diarrhoea DALYs from inadequate hygiene
		WSH_30_SAN	Number of diarrhoea DALYs from inadequate sanitation
		WSH_30_WAT	Number of diarrhoea DALYs from inadequate water
		WSH_30	Number of diarrhoea DALYs from inadequate water, sanitation and hygiene
		WSH_10_HYG	Number of diarrhoea deaths from inadequate hygiene
		WSH_10_SAN	Number of diarrhoea deaths from inadequate sanitation
		WSH_10_WAT	Number of diarrhoea deaths from inadequate water
		WSH_10	Number of diarrhoea deaths from inadequate water, sanitation and hygiene
		WSH_1	SDG 3.9.2 WASH deaths
	
